document.addEventListener("DOMContentLoaded", function () {
  console.log("Grouse Mountain page loaded.");
  // Example: Animating an element when it's clicked
  document.querySelector(".attraction-card").addEventListener("click", function () {
    alert("Explore more about this attraction!");
  });
});
