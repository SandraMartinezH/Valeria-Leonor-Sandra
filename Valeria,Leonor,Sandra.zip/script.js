document.addEventListener('DOMContentLoaded', () => {
    console.log("Welcome to Vancouver Tourism!");
});